#!/bin/bash
#30th Nov 2025
#Maintainer SIDDHARTH 
#This Script will handle the error while creating the directory

dir_path=/tmp/dim-nov
set -e
cd /tmp
#mkdir $dir_path
cd $dir_path || { echo "failed to cd"; exit 1; }
echo "directory location changed"

