#!/bin/bash
#Date 23rd Nov 2025
#Maintainer "DIM Team"
#Creating a new directory and new file in /tmp location
path=/tmp/lab2/testing/
filename=lab2.txt
mkdir -p $path
touch $path$filename
echo "Adding new content" >> $path$filename

echo "Directory and file created asnd now check file content"

cat $path$filename
