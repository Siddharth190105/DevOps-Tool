#!bin/bash
#Date of 23 Nov 2025
#Maintainer DIM team
#Creating a new directory in /tmp

mkdir /tmp/lab1/testing
touch /tmp/lab1/testing/lab1.txt

echo"This shell file is excuted sucessfully"
