#!/bin/bash

key1="color_red"
value1="#FF0000"

key2="color_green"
value2="#00FF00"

echo "$key1 has value $value1"
echo "$key2 has value $value2"
